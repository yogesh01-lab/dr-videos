// const express = require('express');
// const fs = require('fs');
// const path = require('path');
// const app = express();

// app.use(express.json());

// app.get('/api/videos', (req, res) => {
//     fs.readFile(path.join(__dirname, 'data.json'), 'utf8', (err, data) => {
//         if (err) {
//             return res.status(500).json({ error: 'Error reading data' });
//         }
//         res.json(JSON.parse(data));
//     });
// });


// app.post('/api/videos/:id/view', (req, res) => {
//     fs.readFile(path.join(__dirname, 'data.json'), 'utf8', (err, data) => {
//         if (err) {
//             return res.status(500).json({ error: 'Error reading data' });
//         }

//         try {
//             const videos = JSON.parse(data);
//             const video = videos.find(v => v.id === req.params.id);
            
//             if (!video) {
//                 return res.status(404).json({ error: 'Video not found' });
//             }

//             video.count = Number(video.count) + 1;

//             fs.writeFile(
//                 path.join(__dirname, 'data.json'),
//                 JSON.stringify(videos, null, 2),
//                 (err) => {
//                     if (err) {
//                         return res.status(500).json({ error: 'Error writing data' });
//                     }
//                     res.json({ success: true, count: video.count });
//                 }
//             );
//         } catch (err) {
//             res.status(500).json({ error: 'Error processing data' });
//         }
//     });
// });

// const PORT = 3000;
// app.listen(PORT, () => {
//     console.log(`Server running on port ${PORT}`);
// });

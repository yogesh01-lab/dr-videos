import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import usePageView from "./pageView";

const GetVideos = () => {
  const [video, setVideo] = useState(null);
  const { id } = useParams();
  usePageView();

  useEffect(() => {
    const url = "/data.json"; // Ensure this file is in the public folder
    fetch(url)
      .then((response) => {
        console.log("Fetch response:", response); // Log the response
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        console.log("Parsed data:", data); // Log the parsed data
        const selectedVideo = data.find((video) => video.id === id);
        setVideo(selectedVideo);
        console.log("Set video:", selectedVideo);
      })
      .catch((error) => {
        console.error("There was a problem with the fetch operation:", error);
      });
  }, [id]);

  if (!video) {
    return <div>Loading...</div>;
  }

  return (
    <div key={video.id}>
      <h3>{video.name}</h3>
      <video width="320" height="240" controls>
        <source src={video.src} type="video/mp4" />
      </video>
    </div>
  );
};

export default GetVideos;

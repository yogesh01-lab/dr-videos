import { useEffect } from "react";
import GetVideos from './videos';

const usePageView = () => {
    useEffect(() => {
        console.log('Page view: ', window.location.pathname);
        // Call CheckHit here if needed
    },[]);
};

export const CheckHit = (video) => {
    return window.location.pathname === GetVideos(video.id);
};

export default usePageView;
